<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Produit extends Model
{
    use HasFactory;
    protected $fillable = ['Type', 'Reference', 'Designation', 'Id_Categorie', 'Id_Unite_Comptage','Statut','Enregistrer_par'];

    public function categorieProduit(): BelongsTo{
        return $this->belongsTo(CategorieProduit::class, 'Id_Categorie');
    }

    public function uniteDeComptage()
    {
        return $this->belongsTo(UniteComptage::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
